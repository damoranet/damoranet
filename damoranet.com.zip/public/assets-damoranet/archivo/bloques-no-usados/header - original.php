	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- bootstrap 4.3.1 -->
	<link rel="stylesheet" href="css/vendors/Bootstrap/bootstrap.min.css">

	<!-- site header styles -->
	<link href="css/plugins/navigation.min.css" rel="stylesheet">

	<!-- main styles -->
	<link rel="stylesheet" href="css/main.css">

	<!-- theme font -->
	<link rel="stylesheet" type="text/css" href="css/theme-font.min.css">

	<!-- IE11 Support -->
	<script>window.MSInputMethodContext && document.documentMode && document.write('<script src="js/ie11CustomProperties.js"><\x2fscript>');</script>

	<!-- styles for RTL -->
	<!--<link rel="stylesheet" type="text/css" href="css/rtl.min.css">-->

	<!--<title>Marketing Digital en República Dominicana | Damoranet</title>-->

	<!-- Favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="./img/theme-content/favicon/android-chrome-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="./img/theme-content/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="./img/theme-content/favicon/favicon-16x16.png">
	<link rel="manifest" href="./img/theme-content/favicon/site.webmanifest">
	<meta name="msapplication-TileColor" content="#da532c">
	<meta name="theme-color" content="#ffffff">