<!DOCTYPE html>
<html lang="en">
<head>
	<?php include_once ("bloques/header.php"); ?>
</head>
<body>
	<?php include_once ("bloques/main_header.php"); ?>


<!-- MAIN CONTENT WRAPPER -->
<div class="main-content-wrapper">


<p>Pues yo soy el cuerpo de la página que tiene el contenido principal</p>


	<!-- BACK TO TOP -->
	<div class="back-to-top">
		<svg class="crumina-icon">
			<use xlink:href="#icon-back-to-top"></use>
		</svg>
	</div>
	<!-- /BACK TO TOP -->

</div>
<!-- /MAIN CONTENT WRAPPER -->

<?php include_once ("bloques/footer.php"); ?>

</body>
</html>