	<!-- SECCION DE CONTACTO -->
	<div class="medium-padding section-image-bg-dark">
		<div class="container">
			<!-- CONTACTS -->
			<div class="contacts">

				<!-- CONTACTS ITEM -->
				<div class="contacts-item">
					<img loading="lazy" class="crumina-icon" src="<?= base_url('theme-topten/img/demo-content/icons/icon4.svg') ?>" alt="phone">
					<div class="content">
						<div class="title c-white">(849)-356-1112</div>
						<p class="sub-title c-white">Lun-Vie 9am-7pm</p>
					</div>
				</div>
				<!-- /CONTACTS ITEM -->

				<!-- CONTACTS ITEM -->
				<div class="contacts-item">
					<img loading="lazy" class="crumina-icon" src="<?= base_url('theme-topten/img/demo-content/icons/icon5.svg') ?>" alt="mail">
					<div class="content">
						<a href="mailto:info@topten.com" class="title c-white">info@damoranet.com</a>
						<p class="sub-title c-white"></p>
					</div>
				</div>
				<!-- /CONTACTS ITEM -->

				<!-- CONTACTS ITEM -->
				<div class="contacts-item">
					<img loading="lazy" class="crumina-icon" src="<?= base_url('theme-topten/img/demo-content/icons/icon6.svg') ?>" alt="location">
					<div class="content">
						<div class="title c-white">Santo Domingo, Rep.Dom</div>
						<p class="sub-title c-white">Av. República de Colombia </p>
					</div>
				</div>
				<!-- /CONTACTS ITEM -->

			</div>
			<!-- /CONTACTS -->
		</div>
	</div>
	<!-- /SECCION DE CONTACTO -->
